﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestaoEstoque.Classes
{
    class ClassProduto
    {
        public string nome { get; set; }

        public ClassProduto(string nome)
        {
            this.nome = nome;
        }

        public ClassProduto()
        {
        }
    }
}
