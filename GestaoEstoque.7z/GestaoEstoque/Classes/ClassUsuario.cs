﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestaoEstoque.Classes
{
    class ClassUsuario
    {
        public string nome { get; set; }
        public string login { get; set; }
        public string senha { get; set; }
        public string cargo { get; set; }
        public DateTime data { get; set; }

        public ClassUsuario(string nome, string login, string senha, string cargo, DateTime data)
        {
            this.nome = nome;
            this.login = login;
            this.senha = senha;
            this.cargo = cargo;
            this.data = data;
        }

        public ClassUsuario()
        {
        }
    }
}
