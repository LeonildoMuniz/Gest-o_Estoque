﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GestaoEstoque.Classes;
using GestaoEstoque.Servicos;

namespace GestaoEstoque.Servicos
{
    class ClassLogin
    {

        ClassConBanco con = new ClassConBanco();
        
        ClassUsuario classUsuario = new ClassUsuario();

        public void UserLogado()
        {

        }

        public void Inserir()
        {

        }

        public void Excluir()
        {

        }

        public void Editar()
        {

        }

    }
}
