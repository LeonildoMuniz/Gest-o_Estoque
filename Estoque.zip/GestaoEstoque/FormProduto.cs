﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GestaoEstoque.Classes;

namespace GestaoEstoque
{
    public partial class FormProduto : Form
    {

        public FormProduto()
        {
            InitializeComponent();
        }

        public void CarregaDGV()
        {
            ClassProduto produto = new ClassProduto();
            dgvProduto.DataSource = produto.ListaProduto();
        }
        private void txtCodigo_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((Char.IsLetter(e.KeyChar)))
                e.Handled = true;
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtCodigo.Text = "";
            txtProduto.Text = "";
            txtProduto.Focus();
            rdbAtivar.Checked = false;
            btnLocalizar.Enabled = false;
            CarregaDGV();
        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            ClassProduto inserir = new ClassProduto();
            inserir.Inserir(txtProduto.Text);
            txtCodigo.Text = "";
            txtProduto.Text = "";
            txtProduto.Focus();
            rdbAtivar.Checked = false;
            btnLocalizar.Enabled = false;
            CarregaDGV();

        }


        private void btnEditar_Click(object sender, EventArgs e)
        {
            ClassProduto editar = new ClassProduto();
            editar.Editar(Convert.ToInt32(txtCodigo.Text), txtProduto.Text);
            txtCodigo.Text = "";
            txtProduto.Text = "";
            txtProduto.Focus();
            CarregaDGV();
            rdbAtivar.Checked = false;
            btnLocalizar.Enabled = false;

        }


        private void rdbAtivar_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbAtivar.Checked)
            {
                txtCodigo.Enabled = true;
                btnLocalizar.Enabled = true;
                txtCodigo.Focus();

            }
            else
            {
                txtCodigo.Enabled = false;
                btnLocalizar.Enabled = false;
            }
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            ClassProduto excluir = new ClassProduto();
            excluir.Excluir(Convert.ToInt32(txtCodigo.Text));
            txtCodigo.Text = "";
            txtProduto.Text = "";
            txtProduto.Focus();
            rdbAtivar.Checked = false;
            btnLocalizar.Enabled = false;
            CarregaDGV();
        }

        private void btnLocalizar_Click(object sender, EventArgs e)
        {

            try
            {
                ClassProduto localizar = new ClassProduto();
                localizar.Localizar(Convert.ToInt32(txtCodigo.Text));
                txtProduto.Text = localizar.nome.Trim();
            }
            catch (Exception ex)
            {

                MessageBox.Show("Código não existe!");
            }
        }

        private void FormProduto_Load(object sender, EventArgs e)
        {
            ClassProduto lista = new ClassProduto();
            dgvProduto.DataSource = lista.ListaProduto();
        }

    }
  }
