﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Globalization;
using GestaoEstoque.Classes;

namespace GestaoEstoque
{
    public partial class FormEntrada : Form
    {
        public FormEntrada()
        {
            InitializeComponent();
        }

        public void CarregaDGV()
        {
            ClassSaldo saldo = new ClassSaldo();
            dgvSaldos.DataSource = saldo.ListaSaldo();
        }
        public void AtualizaData()
        {
            txtData.Text = DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss");
            txtData.Enabled = false;
        }
        private void FormEntrada_Load(object sender, EventArgs e)
        {
            ClassTipoMov mov = new ClassTipoMov();
            foreach (var item in mov.ListaMovimentoEntrada())
            {
                cbxMovimento.Items.Add(item.nome);
            }
            FormPrincipal pri = new FormPrincipal();
            AtualizaData();
            CarregaDGV();
        }

        private void lblTotal_Click(object sender, EventArgs e)
        {
            Double total = (Double.Parse(txtQuantidade.Text)*Double.Parse(txtUnitario.Text));
            txtTotal.Text = total.ToString();
        }

        private void btnLocalizar_Click(object sender, EventArgs e)
        {
            try
            {
                ClassProduto localizar = new ClassProduto();
                localizar.Localizar(Convert.ToInt32(txtCodigo.Text));
                if (localizar != null)
                {
                    txtProduto.Text = localizar.nome.Trim();
                }
                
            }
            catch (Exception ex)
            {

                MessageBox.Show("Código não existe!");
            }
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtCodigo.Text = "";
            txtProduto.Text = "";
            txtQuantidade.Text = "";
            txtUnitario.Text = "";
            txtTotal.Text = "";
            txtCodigo.Focus();
        }

        private void btnEntrada_Click(object sender, EventArgs e)
        {

            ClassTipoMov tp_mov = new ClassTipoMov();
            int vlr = tp_mov.TP_Mov(cbxMovimento.Text.Trim());
            ClassMovimentacao mov = new ClassMovimentacao();
            mov.Inserir(Convert.ToInt32(txtCodigo.Text),vlr,Convert.ToDateTime(txtData.Text),Convert.ToInt32(txtQuantidade.Text),Convert.ToDouble(txtUnitario.Text),Convert.ToDouble(txtTotal.Text));
            CarregaDGV();
            txtCodigo.Text = "";
            txtProduto.Text = "";
            txtQuantidade.Text = "";
            txtUnitario.Text = "";
            txtTotal.Text = "";
            txtCodigo.Focus();
        }
    }

}
