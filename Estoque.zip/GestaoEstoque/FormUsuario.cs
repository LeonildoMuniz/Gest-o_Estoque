﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GestaoEstoque.Classes;

namespace GestaoEstoque
{
    public partial class FormUsuario : Form
    {
        public FormUsuario()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            FormLogin login = new FormLogin();
            login.Show();
            this.Close();
           
        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            ClassUsuario usuario = new ClassUsuario();
            usuario.Inserir(txtNome.Text,txtUsuario.Text,txtSenha.Text,cbxCargo.Text,Convert.ToDateTime(dateAdmissao.Value));
            txtNome.Text = "";
            txtSenha.Text = "";
            txtUsuario.Text = "";
            dateAdmissao.Value = DateTime.Now;
            cbxCargo.Text = "";
            txtNome.Focus();
        }
    }
}
