﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GestaoEstoque.Classes;

namespace GestaoEstoque
{
    public partial class FormTipoMovimento : Form
    {
        public FormTipoMovimento()
        {
            InitializeComponent();
        }

        public void CarregaDGV()
        {
            ClassTipoMov mov = new ClassTipoMov();
            dgvMovimentos.DataSource = mov.ListaMovimento();
        }
        private void FormTipoMovimento_Load(object sender, EventArgs e)
        {
            CarregaDGV();
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void rdbAtivar_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbAtivar.Checked)
            {
                txtCodigo.Enabled = true;
                txtMovimento.Focus();
                CarregaDGV();
            }
            else
            {
                txtCodigo.Enabled = false;
                CarregaDGV();
            }
        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            ClassTipoMov mov = new ClassTipoMov();
            mov.Inserir(txtMovimento.Text, Convert.ToChar(cbxTipo.Text));
            CarregaDGV();
            txtMovimento.Text = "";
            txtCodigo.Text = "";
            cbxTipo.Text = "";
            txtMovimento.Focus();

        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            ClassTipoMov mov = new ClassTipoMov();
            mov.Editar(Convert.ToInt32(txtCodigo.Text),txtMovimento.Text, Convert.ToChar(cbxTipo.Text));
            CarregaDGV();
            txtMovimento.Text = "";
            txtCodigo.Text = "";
            txtMovimento.Focus();
            cbxTipo.Text = "";
        }

        private void btnLocalizar_Click(object sender, EventArgs e)
        {
            ClassTipoMov mov = new ClassTipoMov();
            mov.Localizar(Convert.ToInt32(txtCodigo.Text));
            txtMovimento.Text = mov.nome.Trim();
            cbxTipo.Text = Convert.ToString(mov.tp_mov);
            txtMovimento.Focus();
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            ClassTipoMov mov = new ClassTipoMov();
            mov.Excluir(Convert.ToInt32(txtCodigo.Text));
            CarregaDGV();
            txtMovimento.Text = "";
            txtCodigo.Text = "";
            cbxTipo.Text = "";
            txtMovimento.Focus();
        }
    }
}
