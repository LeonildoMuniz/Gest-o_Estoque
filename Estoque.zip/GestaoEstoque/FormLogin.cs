﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GestaoEstoque.Classes;

namespace GestaoEstoque
{
    public partial class FormLogin : Form
    {
        public FormLogin()
        {
            FormSplash sp = new FormSplash();
            sp.Show();
            InitializeComponent();
            sp.Close();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnLogar_Click(object sender, EventArgs e)
        {
            ClassUsuario usuario = new ClassUsuario();
            usuario.Login(txtUsuario.Text,txtSenha.Text);
            if (usuario.nome!= null)
            {
                this.Hide();
                FormPrincipal principal = new FormPrincipal();
                principal.Show();
                principal.lblNome.Text = usuario.nome.Trim();
                principal.lblCargo.Text = usuario.cargo.Trim();
                if (usuario.cargo.Trim() == "Gerente")
                {
                    principal.btnEntrada.Visible = true;
                    principal.btnProduto.Visible = true;
                    principal.btnSaida.Visible = true;
                    principal.btnSaldo.Visible = true;
                    principal.btnTpMov.Visible = true;
                }
                else if (usuario.cargo.Trim() == "Almoxarife")
                {
                    principal.btnEntrada.Visible = true;
                    principal.btnProduto.Visible = true;
                    principal.btnSaldo.Visible = true;
                    principal.btnTpMov.Visible = true;
                }
                else if (usuario.cargo.Trim() == "Vendedor")
                {
                    principal.btnProduto.Visible = true;
                    principal.btnSaida.Visible = true;
                    principal.btnSaldo.Visible = true;
                    principal.btnTpMov.Visible = true;
                }

            }
            else
            {
                txtSenha.Text = "";
                txtUsuario.Text = "";
                txtUsuario.Focus();
            }
        }

        private void lblNovoUser_Click(object sender, EventArgs e)
        {
            FormUsuario usuario = new FormUsuario();
            usuario.Show();
            this.Hide();
        }
    }
}
