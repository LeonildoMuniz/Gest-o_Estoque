﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GestaoEstoque.Classes;

namespace GestaoEstoque
{
    public partial class FormPrincipal : Form
    {
        public FormPrincipal()
        {
            InitializeComponent();
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            FormSplash sp = new FormSplash();
            sp.Show();
            this.Close();
        }

        private void btnProduto_Click(object sender, EventArgs e)
        {
            FormProduto produto = new FormProduto();
            produto.Show();
        }

        private void btnTpMov_Click(object sender, EventArgs e)
        {
            FormTipoMovimento mov = new FormTipoMovimento();
            mov.Show();
        }

        private void btnEntrada_Click(object sender, EventArgs e)
        {
            FormEntrada entrada = new FormEntrada();
            entrada.Show();

        }

        private void btnSaida_Click(object sender, EventArgs e)
        {
            FormSaida saida = new FormSaida();
            saida.Show();
        }

        private void btnSaldo_Click(object sender, EventArgs e)
        {
            FormSaldo saldo = new FormSaldo();
            saldo.Show();
        }

        private void FormPrincipal_Load(object sender, EventArgs e)
        {

        }
    }
}
