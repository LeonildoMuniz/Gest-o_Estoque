﻿namespace GestaoEstoque
{
    partial class FormPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnSair = new System.Windows.Forms.Button();
            this.btnFechar = new System.Windows.Forms.Button();
            this.btnSaldo = new System.Windows.Forms.Button();
            this.btnSaida = new System.Windows.Forms.Button();
            this.btnEntrada = new System.Windows.Forms.Button();
            this.btnTpMov = new System.Windows.Forms.Button();
            this.btnProduto = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblCargo = new System.Windows.Forms.Label();
            this.lblNome = new System.Windows.Forms.Label();
            this.lblUsuario = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Gainsboro;
            this.panel1.Controls.Add(this.btnSair);
            this.panel1.Controls.Add(this.btnFechar);
            this.panel1.Controls.Add(this.btnSaldo);
            this.panel1.Controls.Add(this.btnSaida);
            this.panel1.Controls.Add(this.btnEntrada);
            this.panel1.Controls.Add(this.btnTpMov);
            this.panel1.Controls.Add(this.btnProduto);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(217, 700);
            this.panel1.TabIndex = 0;
            // 
            // btnSair
            // 
            this.btnSair.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnSair.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnSair.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSair.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.btnSair.FlatAppearance.BorderSize = 0;
            this.btnSair.Font = new System.Drawing.Font("Nirmala UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSair.ForeColor = System.Drawing.Color.DimGray;
            this.btnSair.Image = global::GestaoEstoque.Properties.Resources.icons8_sair_30;
            this.btnSair.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSair.Location = new System.Drawing.Point(0, 594);
            this.btnSair.Margin = new System.Windows.Forms.Padding(2);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(217, 52);
            this.btnSair.TabIndex = 7;
            this.btnSair.Text = "Logout";
            this.btnSair.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSair.UseVisualStyleBackColor = false;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // btnFechar
            // 
            this.btnFechar.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnFechar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnFechar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnFechar.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.btnFechar.FlatAppearance.BorderSize = 0;
            this.btnFechar.Font = new System.Drawing.Font("Nirmala UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFechar.ForeColor = System.Drawing.Color.DimGray;
            this.btnFechar.Image = global::GestaoEstoque.Properties.Resources.icons8_cancelar_30;
            this.btnFechar.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnFechar.Location = new System.Drawing.Point(0, 646);
            this.btnFechar.Margin = new System.Windows.Forms.Padding(2);
            this.btnFechar.Name = "btnFechar";
            this.btnFechar.Size = new System.Drawing.Size(217, 54);
            this.btnFechar.TabIndex = 6;
            this.btnFechar.Text = "Fechar";
            this.btnFechar.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnFechar.UseVisualStyleBackColor = false;
            this.btnFechar.Click += new System.EventHandler(this.btnFechar_Click);
            // 
            // btnSaldo
            // 
            this.btnSaldo.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnSaldo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnSaldo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSaldo.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnSaldo.FlatAppearance.BorderSize = 0;
            this.btnSaldo.Font = new System.Drawing.Font("Nirmala UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaldo.ForeColor = System.Drawing.Color.DimGray;
            this.btnSaldo.Image = global::GestaoEstoque.Properties.Resources.icons8_contabilidade_30;
            this.btnSaldo.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSaldo.Location = new System.Drawing.Point(0, 389);
            this.btnSaldo.Margin = new System.Windows.Forms.Padding(2);
            this.btnSaldo.Name = "btnSaldo";
            this.btnSaldo.Size = new System.Drawing.Size(217, 54);
            this.btnSaldo.TabIndex = 5;
            this.btnSaldo.Text = "Saldo";
            this.btnSaldo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSaldo.UseVisualStyleBackColor = false;
            this.btnSaldo.Visible = false;
            this.btnSaldo.Click += new System.EventHandler(this.btnSaldo_Click);
            // 
            // btnSaida
            // 
            this.btnSaida.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnSaida.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnSaida.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSaida.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnSaida.FlatAppearance.BorderSize = 0;
            this.btnSaida.Font = new System.Drawing.Font("Nirmala UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaida.ForeColor = System.Drawing.Color.DimGray;
            this.btnSaida.Image = global::GestaoEstoque.Properties.Resources.icons8_retirada_30;
            this.btnSaida.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSaida.Location = new System.Drawing.Point(0, 335);
            this.btnSaida.Margin = new System.Windows.Forms.Padding(2);
            this.btnSaida.Name = "btnSaida";
            this.btnSaida.Size = new System.Drawing.Size(217, 54);
            this.btnSaida.TabIndex = 4;
            this.btnSaida.Text = "Saida de estoque";
            this.btnSaida.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSaida.UseVisualStyleBackColor = false;
            this.btnSaida.Visible = false;
            this.btnSaida.Click += new System.EventHandler(this.btnSaida_Click);
            // 
            // btnEntrada
            // 
            this.btnEntrada.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnEntrada.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnEntrada.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnEntrada.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnEntrada.FlatAppearance.BorderSize = 0;
            this.btnEntrada.Font = new System.Drawing.Font("Nirmala UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEntrada.ForeColor = System.Drawing.Color.DimGray;
            this.btnEntrada.Image = global::GestaoEstoque.Properties.Resources.icons8_adicionar_regra_30;
            this.btnEntrada.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnEntrada.Location = new System.Drawing.Point(0, 281);
            this.btnEntrada.Margin = new System.Windows.Forms.Padding(2);
            this.btnEntrada.Name = "btnEntrada";
            this.btnEntrada.Size = new System.Drawing.Size(217, 54);
            this.btnEntrada.TabIndex = 3;
            this.btnEntrada.Text = "Entrada de estoque";
            this.btnEntrada.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnEntrada.UseVisualStyleBackColor = false;
            this.btnEntrada.Visible = false;
            this.btnEntrada.Click += new System.EventHandler(this.btnEntrada_Click);
            // 
            // btnTpMov
            // 
            this.btnTpMov.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnTpMov.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnTpMov.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTpMov.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnTpMov.FlatAppearance.BorderSize = 0;
            this.btnTpMov.Font = new System.Drawing.Font("Nirmala UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTpMov.ForeColor = System.Drawing.Color.DimGray;
            this.btnTpMov.Image = global::GestaoEstoque.Properties.Resources.icons8_movimento_de_estoque_30;
            this.btnTpMov.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnTpMov.Location = new System.Drawing.Point(0, 227);
            this.btnTpMov.Margin = new System.Windows.Forms.Padding(2);
            this.btnTpMov.Name = "btnTpMov";
            this.btnTpMov.Size = new System.Drawing.Size(217, 54);
            this.btnTpMov.TabIndex = 2;
            this.btnTpMov.Text = "Cadastrar Tipo Mov.";
            this.btnTpMov.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnTpMov.UseVisualStyleBackColor = false;
            this.btnTpMov.Visible = false;
            this.btnTpMov.Click += new System.EventHandler(this.btnTpMov_Click);
            // 
            // btnProduto
            // 
            this.btnProduto.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnProduto.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnProduto.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnProduto.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnProduto.FlatAppearance.BorderSize = 0;
            this.btnProduto.Font = new System.Drawing.Font("Nirmala UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProduto.ForeColor = System.Drawing.Color.DimGray;
            this.btnProduto.Image = global::GestaoEstoque.Properties.Resources.icons8_produto_30;
            this.btnProduto.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnProduto.Location = new System.Drawing.Point(0, 173);
            this.btnProduto.Margin = new System.Windows.Forms.Padding(2);
            this.btnProduto.Name = "btnProduto";
            this.btnProduto.Size = new System.Drawing.Size(217, 54);
            this.btnProduto.TabIndex = 1;
            this.btnProduto.Text = "Cadastrar Produto";
            this.btnProduto.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnProduto.UseVisualStyleBackColor = false;
            this.btnProduto.Visible = false;
            this.btnProduto.Click += new System.EventHandler(this.btnProduto_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.lblCargo);
            this.panel2.Controls.Add(this.lblNome);
            this.panel2.Controls.Add(this.lblUsuario);
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(217, 173);
            this.panel2.TabIndex = 1;
            // 
            // lblCargo
            // 
            this.lblCargo.Font = new System.Drawing.Font("Nirmala UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCargo.ForeColor = System.Drawing.Color.SlateBlue;
            this.lblCargo.Location = new System.Drawing.Point(17, 144);
            this.lblCargo.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblCargo.Name = "lblCargo";
            this.lblCargo.Size = new System.Drawing.Size(188, 18);
            this.lblCargo.TabIndex = 3;
            this.lblCargo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNome
            // 
            this.lblNome.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblNome.Font = new System.Drawing.Font("Nirmala UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNome.ForeColor = System.Drawing.Color.SlateBlue;
            this.lblNome.Image = global::GestaoEstoque.Properties.Resources.icons8_editar_30;
            this.lblNome.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblNome.Location = new System.Drawing.Point(20, 110);
            this.lblNome.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(187, 20);
            this.lblNome.TabIndex = 2;
            this.lblNome.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblUsuario
            // 
            this.lblUsuario.Font = new System.Drawing.Font("Nirmala UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUsuario.ForeColor = System.Drawing.Color.SlateBlue;
            this.lblUsuario.Location = new System.Drawing.Point(17, 93);
            this.lblUsuario.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblUsuario.Name = "lblUsuario";
            this.lblUsuario.Size = new System.Drawing.Size(188, 18);
            this.lblUsuario.TabIndex = 1;
            this.lblUsuario.Text = "Bem-Vindo(a)";
            this.lblUsuario.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::GestaoEstoque.Properties.Resources.icons8_user_64;
            this.pictureBox1.Location = new System.Drawing.Point(65, 10);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(89, 80);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Silver;
            this.panel3.Controls.Add(this.label1);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(217, 0);
            this.panel3.Margin = new System.Windows.Forms.Padding(2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(717, 76);
            this.panel3.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Font = new System.Drawing.Font("Nirmala UI", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.SlateBlue;
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(717, 76);
            this.label1.TabIndex = 0;
            this.label1.Text = "Dashboard Estoque";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel4
            // 
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(217, 76);
            this.panel4.Margin = new System.Windows.Forms.Padding(2);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(717, 624);
            this.panel4.TabIndex = 2;
            // 
            // FormPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(934, 700);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "FormPrincipal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormPrincipal";
            this.Load += new System.EventHandler(this.FormPrincipal_Load);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblUsuario;
        public System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Button btnSair;
        private System.Windows.Forms.Button btnFechar;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel4;
        public System.Windows.Forms.Label lblCargo;
        public System.Windows.Forms.Button btnProduto;
        public System.Windows.Forms.Button btnTpMov;
        public System.Windows.Forms.Button btnEntrada;
        public System.Windows.Forms.Button btnSaida;
        public System.Windows.Forms.Button btnSaldo;
    }
}