﻿namespace GestaoEstoque
{
    partial class FormSplash
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pn2 = new System.Windows.Forms.FlowLayoutPanel();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.lblSplash = new System.Windows.Forms.Label();
            this.lblCarregar = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.pn2);
            this.panel1.Location = new System.Drawing.Point(12, 298);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(599, 21);
            this.panel1.TabIndex = 0;
            // 
            // pn2
            // 
            this.pn2.BackColor = System.Drawing.Color.BlueViolet;
            this.pn2.Location = new System.Drawing.Point(0, 0);
            this.pn2.Name = "pn2";
            this.pn2.Size = new System.Drawing.Size(33, 21);
            this.pn2.TabIndex = 1;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 15;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // lblSplash
            // 
            this.lblSplash.Font = new System.Drawing.Font("Nirmala UI", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSplash.ForeColor = System.Drawing.Color.SlateBlue;
            this.lblSplash.Image = global::GestaoEstoque.Properties.Resources.icons8_contabilidade_80;
            this.lblSplash.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblSplash.Location = new System.Drawing.Point(12, 47);
            this.lblSplash.Name = "lblSplash";
            this.lblSplash.Size = new System.Drawing.Size(599, 161);
            this.lblSplash.TabIndex = 1;
            this.lblSplash.Text = "Controle de Estoque";
            this.lblSplash.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblCarregar
            // 
            this.lblCarregar.Font = new System.Drawing.Font("Nirmala UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCarregar.ForeColor = System.Drawing.Color.SlateBlue;
            this.lblCarregar.Location = new System.Drawing.Point(177, 273);
            this.lblCarregar.Name = "lblCarregar";
            this.lblCarregar.Size = new System.Drawing.Size(250, 22);
            this.lblCarregar.TabIndex = 2;
            this.lblCarregar.Text = "Aguarde";
            this.lblCarregar.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // FormSplash
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(623, 366);
            this.Controls.Add(this.lblCarregar);
            this.Controls.Add(this.lblSplash);
            this.Controls.Add(this.panel1);
            this.ForeColor = System.Drawing.Color.White;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FormSplash";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormSplash";
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.FlowLayoutPanel pn2;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label lblSplash;
        private System.Windows.Forms.Label lblCarregar;
    }
}