﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GestaoEstoque.Classes
{
    class ClassProduto
    {

        public int id { get; set; }
        public string nome { get; set; }


        public ClassProduto(string nome, int id)
        {
            this.id = id;
            this.nome = nome;
           
        }

        public ClassProduto()
        {
        }
        public List<ClassProduto> ListaProduto()
        {
            SqlConnection con = ClassConBanco.ObterConexao();
            List<ClassProduto> li = new List<ClassProduto>();
            string sql = "SELECT * FROM Produto";
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                ClassProduto p = new ClassProduto();
                p.id = (int)dr["Id"];
                p.nome = dr["nome"].ToString();

                li.Add(p);
            }
            ClassConBanco.FecharConexao();
            return li;
        }

        public void Localizar(int id)
        {
            SqlConnection con = ClassConBanco.ObterConexao();
            string sql = "SELECT * FROM Produto WHERE Id='"+id+"'";
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                id = (int)dr["Id"];
                nome = dr["nome"].ToString();
            }

            ClassConBanco.FecharConexao();
        }

        public void Inserir(string nome)
        {
            try
            {
                SqlConnection con = ClassConBanco.ObterConexao();
                string sql = "INSERT INTO Produto(nome) VALUES  ('" + nome + "')" ;
                SqlCommand cmd = new SqlCommand(sql, con);
                cmd.ExecuteNonQuery();
                ClassConBanco.FecharConexao();
                con.Open();
                sql = "SELECT IDENT_CURRENT('Produto') AS 'Id'";
                cmd = new SqlCommand(sql, con);
                int vlr = Convert.ToInt32(cmd.ExecuteScalar());
                
                ClassConBanco.FecharConexao();
                con.Open();
                sql = "INSERT INTO Saldo(id_produto,quantidade,unitario,total) VALUES  ('" + vlr + "','0','0','0')";
                cmd = new SqlCommand(sql, con);
                cmd.ExecuteNonQuery();
                ClassConBanco.FecharConexao();

                MessageBox.Show("Cadastro Efetuado com sucesso!");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public void Editar(int id, string nome)
        {
            try
            {
                SqlConnection con = ClassConBanco.ObterConexao();
                string sql = "UPDATE Produto SET nome='" + nome + "'  WHERE Id = '" + id + "'";
                SqlCommand cmd = new SqlCommand(sql, con);
                cmd.ExecuteNonQuery();
                ClassConBanco.FecharConexao();
                MessageBox.Show("Cadastro Editado com Sucesso!");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public void Excluir(int id)
        {
            try
            {

                DialogResult confirma = MessageBox.Show("Tem certeza que deseja excluir?", "Atenção!",MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);


                if (confirma.ToString().ToUpper() == "YES")
                {
                    SqlConnection con = ClassConBanco.ObterConexao();
                    string sql = "SELECT quantidade FROM Saldo WHERE Id_produto='"+id+"'";
                    SqlCommand cmd = new SqlCommand(sql, con);
                    int vlr = Convert.ToInt32(cmd.ExecuteScalar());
                    if (vlr>0)
                    {
                        MessageBox.Show("Codigo possui saldo de estoque, não pode ser excluido!");
                        ClassConBanco.FecharConexao();
                    }
                    else
                    {
                        sql = "DELETE FROM Produto WHERE Id = '" + id + "'";
                        cmd = new SqlCommand(sql, con);
                        cmd.ExecuteNonQuery();
                        sql = "DELETE FROM Saldo WHERE Id_produto = '" + id + "'";
                        cmd = new SqlCommand(sql, con);
                        cmd.ExecuteNonQuery();
                        ClassConBanco.FecharConexao();
                        MessageBox.Show("Cadastro Excluido com Sucesso");
                    }




                }
                else
                {
                    MessageBox.Show("Processo abortado!");
                }
                

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
    }
}
