﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GestaoEstoque.Classes
{
    class ClassTipoMov
    {

        public int id { get; set; }
        public char tp_mov { get; set; }
        public string nome { get; set; }

        public ClassTipoMov(string nome, char tp_mov, int id)
        {
            this.id = id;
            this.tp_mov = tp_mov;
            this.nome = nome;
            
            
        }

        public ClassTipoMov()
        {
        }


        public List<ClassTipoMov> ListaMovimento()
        {
            SqlConnection con = ClassConBanco.ObterConexao();
            List<ClassTipoMov> li = new List<ClassTipoMov>();
            string sql = "SELECT * FROM TP_Movimento";
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                ClassTipoMov m = new ClassTipoMov();
                m.id = (int)dr["Id"];
                m.tp_mov = Convert.ToChar(dr["tp_mov"]);
                m.nome = dr["nome"].ToString();


                li.Add(m);
            }
            ClassConBanco.FecharConexao();
            return li;
        }

        public List<ClassTipoMov> ListaMovimentoEntrada()
        {
            SqlConnection con = ClassConBanco.ObterConexao();
            List<ClassTipoMov> li = new List<ClassTipoMov>();
            string sql = "SELECT * FROM TP_Movimento WHERE tp_mov='E'";
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                ClassTipoMov m = new ClassTipoMov();
                m.id = (int)dr["Id"];
                m.tp_mov = Convert.ToChar(dr["tp_mov"]);
                m.nome = dr["nome"].ToString();


                li.Add(m);
            }
            ClassConBanco.FecharConexao();
            return li;
        }

        public List<ClassTipoMov> ListaMovimentoSaida()
        {
            SqlConnection con = ClassConBanco.ObterConexao();
            List<ClassTipoMov> li = new List<ClassTipoMov>();
            string sql = "SELECT * FROM TP_Movimento WHERE tp_mov='S'";
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                ClassTipoMov m = new ClassTipoMov();
                m.id = (int)dr["Id"];
                m.tp_mov = Convert.ToChar(dr["tp_mov"]);
                m.nome = dr["nome"].ToString();


                li.Add(m);
            }
            ClassConBanco.FecharConexao();
            return li;
        }

        public int TP_Mov(string nome)
        {
            SqlConnection con = ClassConBanco.ObterConexao();
            string sql = "SELECT Id FROM TP_Movimento WHERE nome='"+ nome +"'";
            SqlCommand cmd = new SqlCommand(sql, con);
            int vlr = Convert.ToInt32(cmd.ExecuteScalar());
            return vlr;
        }

        public void Localizar(int id)
        {
            SqlConnection con = ClassConBanco.ObterConexao();
            string sql = "SELECT * FROM TP_Movimento WHERE Id='" + id + "'";
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                id = (int)dr["Id"];
                nome = dr["nome"].ToString();
                tp_mov = Convert.ToChar(dr["tp_mov"]);
            }

            ClassConBanco.FecharConexao();
        }

        public void Inserir(string movimento, char tipo)
        {
            try
            {
                SqlConnection con = ClassConBanco.ObterConexao();
                string sql = "INSERT INTO TP_Movimento(nome, tp_mov) VALUES  ('" + movimento + "','" + tipo + "')";
                SqlCommand cmd = new SqlCommand(sql, con);
                cmd.ExecuteNonQuery();
                ClassConBanco.FecharConexao();
                MessageBox.Show("Cadastro Efetuado com sucesso!");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public void Editar(int id, string nome, char tipo)
        {
            try
            {
                SqlConnection con = ClassConBanco.ObterConexao();
                string sql = "UPDATE TP_Movimento SET nome='" + nome + "',tp_mov='" + tipo + "'  WHERE Id = '" + id + "'";
                SqlCommand cmd = new SqlCommand(sql, con);
                cmd.ExecuteNonQuery();
                ClassConBanco.FecharConexao();
                MessageBox.Show("Cadastro Editado com Sucesso!");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        public void Excluir(int id)
        {
            try
            {

                DialogResult confirma = MessageBox.Show("Tem certeza que deseja excluir?", "Atenção!", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);


                if (confirma.ToString().ToUpper() == "YES")
                {
                    SqlConnection con = ClassConBanco.ObterConexao();
                    string sql = "DELETE FROM TP_Movimento WHERE Id = '" + id + "'";
                    SqlCommand cmd = new SqlCommand(sql, con);
                    cmd.ExecuteNonQuery();
                    ClassConBanco.FecharConexao();
                    MessageBox.Show("Cadastro Excluido com Sucesso");
                }
                else
                {
                    MessageBox.Show("Processo abortado!");
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }


    }
}
