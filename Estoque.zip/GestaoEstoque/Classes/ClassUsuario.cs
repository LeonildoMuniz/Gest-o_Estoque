﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GestaoEstoque.Classes;

namespace GestaoEstoque.Classes
{
    class ClassUsuario
    {
        public string nome { get; set; }
        public string login { get; set; }
        public string senha { get; set; }
        public string cargo { get; set; }
        public DateTime data { get; set; }

        public ClassUsuario(string nome, string login, string senha, string cargo, DateTime data)
        {
            this.nome = nome;
            this.login = login;
            this.senha = senha;
            this.cargo = cargo;
            this.data = data;
        }

        public ClassUsuario()
        {
        }

        public string Login(string login, string senha)
        {
            try
            {
                
                SqlConnection con = ClassConBanco.ObterConexao();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandText = "SELECT * FROM Usuario Where login=@login AND senha=@senha";
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@login", SqlDbType.NChar).Value = login.Trim();
                cmd.Parameters.AddWithValue("@senha", SqlDbType.NChar).Value = senha.Trim();
                SqlDataReader usuario = cmd.ExecuteReader();
                if (usuario.HasRows)
                {
                    while (usuario.Read())
                    {
                        nome = usuario["nome"].ToString();
                        cargo = usuario["cargo"].ToString();
                    }
                    
                    ClassConBanco.FecharConexao();
                    return nome;
                }
                else
                {
                    MessageBox.Show("Login ou senha inválido! Por favor, tente novamente!", "Erro de login", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    ClassConBanco.FecharConexao();
                    return null;
                }
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);
                return null;
            }

        }

        public void Inserir(string nome, string login,string senha, string cargo, DateTime data_admissao)
        {
            try
            {
                SqlConnection con = ClassConBanco.ObterConexao();
                string dta = data_admissao.ToString("yyyy/MM/dd");
                string sql = "INSERT INTO Usuario(nome, login, senha, cargo,data_admissao) VALUES  ('" +nome+ "','" +login+ "','" + senha + "','" + cargo + "','" + dta + "')";
                SqlCommand cmd = new SqlCommand(sql, con);
                cmd.ExecuteNonQuery();
                ClassConBanco.FecharConexao();
                MessageBox.Show("Cadastro Efetuado com sucesso!");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


    }
}
