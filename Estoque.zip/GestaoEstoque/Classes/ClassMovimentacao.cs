﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestaoEstoque.Classes
{
    class ClassMovimentacao
    {
        public int id_produto { get; set; }
        public int id_tipo_mov { get; set; }
        public DateTime data { get; set; }
        public int quantidade { get; set; }
        public double unitario { get; set; }
        public double total { get; set; }
        public string usuario { get; set; }

        public ClassMovimentacao(int id_produto, int id_tipo_mov, DateTime data, int quantidade, double unitario, double total, string usuario)
        {
            this.id_produto = id_produto;
            this.id_tipo_mov = id_tipo_mov;
            this.data = data;
            this.quantidade = quantidade;
            this.unitario = unitario;
            this.total = total;
            this.usuario = usuario;
        }

        public ClassMovimentacao()
        {
        }
    }
}
