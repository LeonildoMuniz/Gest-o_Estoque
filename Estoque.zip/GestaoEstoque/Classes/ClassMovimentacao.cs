﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GestaoEstoque.Classes;

namespace GestaoEstoque.Classes
{
    class ClassMovimentacao
    {
        public int id { get; set; }
        public int id_produto { get; set; }
        public int id_tipo_mov { get; set; }
        public DateTime data { get; set; }
        public int quantidade { get; set; }
        public double unitario { get; set; }
        public double total { get; set; }

        public ClassMovimentacao(int id, int id_produto, int id_tipo_mov, DateTime data, int quantidade, double unitario, double total)
        {
            this.id = id;
            this.id_produto = id_produto;
            this.id_tipo_mov = id_tipo_mov;
            this.data = data;
            this.quantidade = quantidade;
            this.unitario = unitario;
            this.total = total;
        }

        public ClassMovimentacao()
        {
        }

        public List<ClassSaldo> ListaSaldo()
        {
            SqlConnection con = ClassConBanco.ObterConexao();
            List<ClassSaldo> li = new List<ClassSaldo>();
            string sql = "SELECT * FROM Movimentacao";
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                ClassSaldo p = new ClassSaldo();
                p.id = (int)dr["Id"];
                p.id_produto = (int)dr["Id_produto"];
                p.quantidade = (int)dr["quantidade"];
                p.unitario = Convert.ToDouble(dr["unitario"]);
                p.total = Convert.ToDouble(dr["total"]);
                li.Add(p);
            }
            ClassConBanco.FecharConexao();
            return li;
        }

        public void Inserir(int id_produto, int id_tipo_mov, DateTime data, int quantidade, double unitario, double total)
        {
            try
            {
                string dta = data.ToString("yyyy/MM/dd");
                string vlr = unitario.ToString();
                string num1 = vlr.Replace(',', '.');
                string vlr2 = total.ToString();
                string num2 = vlr2.Replace(',', '.');
                SqlConnection con = ClassConBanco.ObterConexao();
                string sql = "INSERT INTO Movimentacao(id_produto,id_tipo_mov, data, quantidade, unitario, total) VALUES  ('" + id_produto + "','" + id_tipo_mov + "','" + dta + "','" + quantidade + "','" + num1 + "','" + num2 + "')";
                SqlCommand cmd = new SqlCommand(sql, con);
                cmd.ExecuteNonQuery();
                ClassConBanco.FecharConexao();

                con.Open();
                sql = "SELECT * FROM Saldo WHERE Id_produto='" + id_produto + "'";
                cmd = new SqlCommand(sql, con);
                SqlDataReader dr = cmd.ExecuteReader();
                ClassMovimentacao m = new ClassMovimentacao();
                while (dr.Read())
                {
                    m.quantidade = (int)dr["quantidade"];
                    m.unitario = Convert.ToDouble(dr["unitario"]);
                    m.total = Convert.ToDouble(dr["total"]);
                }
                ClassConBanco.FecharConexao();

                quantidade += m.quantidade;
                total += m.total;
                unitario = total / quantidade;
                vlr = unitario.ToString();
                num1 = vlr.Replace(',', '.');
                vlr2 = total.ToString();
                num2 = vlr2.Replace(',', '.');

                con.Open();
                sql = "UPDATE Saldo SET quantidade='" + quantidade + "',unitario='" + num1 + "',total='" + num2 + "'  WHERE Id_produto = '" + id_produto + "'";
                cmd = new SqlCommand(sql, con);
                cmd.ExecuteNonQuery();

                ClassConBanco.FecharConexao();

                MessageBox.Show("Entrada de estoque Efetuada com sucesso!");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public void excluir(int id_produto, int id_tipo_mov, DateTime data, int quantidade, double unitario, double total)
        {
            try
            {
                string dta = data.ToString("yyyy/MM/dd");
                string vlr = unitario.ToString();
                string num1 = vlr.Replace(',', '.');
                string vlr2 = total.ToString();
                string num2 = vlr2.Replace(',', '.');

                SqlConnection con = ClassConBanco.ObterConexao();
                string sql = "SELECT * FROM Saldo WHERE Id_produto='" + id_produto + "'";
                SqlCommand cmd = new SqlCommand(sql, con);
                SqlDataReader dr = cmd.ExecuteReader();
                ClassMovimentacao m = new ClassMovimentacao();
                while (dr.Read())
                {
                    m.quantidade = (int)dr["quantidade"];
                    m.unitario = Convert.ToDouble(dr["unitario"]);
                    m.total = Convert.ToDouble(dr["total"]);
                }
                ClassConBanco.FecharConexao();

                if (quantidade>m.quantidade)
                {
                    MessageBox.Show("Saldo insuficiente para realizar a saída!");
                }
                else
                {

                    con.Open();
                    sql = "INSERT INTO Movimentacao(id_produto,id_tipo_mov, data, quantidade, unitario, total) VALUES  ('" + id_produto + "','" + id_tipo_mov + "','" + dta + "','" + quantidade + "','" + num1 + "','" + num2 + "')";
                    cmd = new SqlCommand(sql, con);
                    cmd.ExecuteNonQuery();
                    ClassConBanco.FecharConexao();

                    quantidade -= m.quantidade;
                    total -= m.total;
                    unitario = total / quantidade;
                    vlr = unitario.ToString();
                    num1 = vlr.Replace(',', '.');
                    vlr2 = total.ToString();
                    num2 = vlr2.Replace(',', '.');

                    con.Open();
                    sql = "UPDATE Saldo SET quantidade='" + quantidade + "',unitario='" + num1 + "',total='" + num2 + "'  WHERE Id_produto = '" + id_produto + "'";
                    cmd = new SqlCommand(sql, con);
                    cmd.ExecuteNonQuery();

                    ClassConBanco.FecharConexao();

                    MessageBox.Show("Saida de estoque Efetuada com sucesso!");
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


    }
}
