﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GestaoEstoque.Classes;

namespace GestaoEstoque
{
    public partial class FormLogin : Form
    {
        public FormLogin()
        {
            FormSplash sp = new FormSplash();
            sp.Show();
            InitializeComponent();
            sp.Close();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnLogar_Click(object sender, EventArgs e)
        {
            ClassUsuario usuario = new ClassUsuario();
            usuario.Login(txtUsuario.Text,txtSenha.Text);
            if (usuario.nome!= null)
            {
                this.Hide();
                FormPrincipal principal = new FormPrincipal();
                principal.Show();
               principal.lblNome.Text = usuario.nome;
                
            }
            else
            {
                txtSenha.Text = "";
                txtUsuario.Text = "";
                txtUsuario.Focus();
            }
        }
    }
}
