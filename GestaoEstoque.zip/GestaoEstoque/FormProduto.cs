﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GestaoEstoque.Classes;

namespace GestaoEstoque
{
    public partial class FormProduto : Form
    {

        public void AutoCompleteProdutos(int id)
        {
            ClassProduto lista = new ClassProduto();
            var source = new AutoCompleteStringCollection();

            txtProduto.AutoCompleteCustomSource = source;
            txtProduto.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            txtProduto.AutoCompleteSource = AutoCompleteSource.CustomSource;

            foreach (var nome in lista.AutoComplete(Convert.ToInt32(id)))
            {
                source.Add(lista.nome);
            }
        }
        public FormProduto()
        {
            InitializeComponent();
        }

        public void CarregaDGV()
        {
            ClassProduto produto = new ClassProduto();
            dgvProduto.DataSource = produto.ListaProduto();
        }
        private void txtCodigo_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((Char.IsLetter(e.KeyChar)))
                e.Handled = true;
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtCodigo.Text = "";
            txtProduto.Text = "";
            txtProduto.Focus();
        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            ClassProduto inserir = new ClassProduto();
            inserir.Inserir(txtProduto.Text);
            txtCodigo.Text = "";
            txtProduto.Text = "";
            txtProduto.Focus();
            rdbAtivar.Checked = false;
            CarregaDGV();

        }

        private void FormProduto_Load(object sender, EventArgs e)
        {
            AutoCompleteProdutos(Convert.ToInt32(3));
            CarregaDGV();
            
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            ClassProduto editar = new ClassProduto();
            editar.Editar(Convert.ToInt32(txtCodigo.Text), txtProduto.Text);
            txtCodigo.Text = "";
            txtProduto.Text = "";
            txtProduto.Focus();
            CarregaDGV();
            rdbAtivar.Checked = false;
            
        }

        private void txtCodigo_TextChanged(object sender, EventArgs e)
        {
            txtCodigo.Modified = true;
        }

        private void rdbAtivar_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbAtivar.Checked)
            {
                txtCodigo.Enabled = true;
                txtCodigo.Focus();

            }
            else
            {
                txtCodigo.Enabled = false;
            }
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            ClassProduto excluir = new ClassProduto();
            excluir.Excluir(Convert.ToInt32(txtCodigo.Text));
            txtCodigo.Text = "";
            txtProduto.Text = "";
            txtProduto.Focus();
            rdbAtivar.Checked = false;
            CarregaDGV();
        }

        private void txtProduto_KeyPress(object sender, KeyPressEventArgs e)
        {
            
        }
    }
  }
