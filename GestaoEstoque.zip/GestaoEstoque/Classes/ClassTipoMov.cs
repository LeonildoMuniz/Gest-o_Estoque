﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestaoEstoque.Classes
{
    class ClassTipoMov
    {
        public string nome { get; set; }
        public char tp_mov { get; set; }

        public ClassTipoMov(string nome, char tp_mov)
        {
            this.nome = nome;
            this.tp_mov = tp_mov;
        }

        public ClassTipoMov()
        {
        }
    }
}
