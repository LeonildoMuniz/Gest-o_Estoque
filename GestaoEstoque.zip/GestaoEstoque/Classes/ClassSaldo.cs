﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestaoEstoque.Classes
{
    class ClassSaldo
    {
        public int id_produto { get; set; }
        public int quantidade { get; set; }
        public double unitario { get; set; }
        public double total { get; set; }

        public ClassSaldo(int id_produto, int quantidade, double unitario, double total)
        {
            this.id_produto = id_produto;
            this.quantidade = quantidade;
            this.unitario = unitario;
            this.total = total;
        }

        public ClassSaldo()
        {
        }
    }
}
